// KepinDumper engine: dump orchestrator + writers.
// Port of Il2CppDecompiler (dump.cs) + string literal + script.json + info.

import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';
import 'elf.dart';
import 'metadata.dart';
import 'registration.dart';
import 'type_names.dart';

typedef DumpProgress = void Function(String phase, int pct, String detail);

class DumpResult {
  final bool ok;
  final String? error;
  final String outDir;
  final List<String> files;
  final Map<String, dynamic> stats;
  DumpResult(this.ok, this.error, this.outDir, this.files, this.stats);
}

class _OutWriter {
  final RandomAccessFile _raf;
  final StringBuffer _buf = StringBuffer();
  _OutWriter(String path) : _raf = File(path).openSync(mode: FileMode.write);
  void w(String s) {
    _buf.write(s);
    if (_buf.length > 262144) _flush();
  }

  void wl([String s = '']) {
    _buf.write(s);
    _buf.write('\n');
    if (_buf.length > 262144) _flush();
  }

  void _flush() {
    if (_buf.isEmpty) return;
    final s = _buf.toString();
    _buf.clear();
    _raf.writeFromSync(utf8.encode(s));
  }

  void close() {
    _flush();
    _raf.closeSync();
  }
}

String _hex(int v) => v.toRadixString(16).toUpperCase();

String _jsonEscape(String s) {
  final sb = StringBuffer();
  for (int i = 0; i < s.length; i++) {
    final c = s.codeUnitAt(i);
    if (c == 0x22) {
      sb.write(r'\"');
    } else if (c == 0x5C) {
      sb.write(r'\\');
    } else if (c == 0x0A) {
      sb.write(r'\n');
    } else if (c == 0x0D) {
      sb.write(r'\r');
    } else if (c == 0x09) {
      sb.write(r'\t');
    } else if (c < 0x20) {
      sb.write('\\u');
      sb.write(c.toRadixString(16).padLeft(4, '0'));
    } else {
      sb.writeCharCode(c);
    }
  }
  return sb.toString();
}

// flag attributes (Il2CppConstants)
const int _typeVisibilityMask = 0x00000007;
const int _typePublic = 0x1;
const int _typeNestedPublic = 0x2;
const int _typeNestedPrivate = 0x3;
const int _typeNestedFamily = 0x4;
const int _typeNestedAssembly = 0x5;
const int _typeNestedFamAndAssem = 0x6;
const int _typeNestedFamOrAssem = 0x7;
const int _typeInterface = 0x00000020;
const int _typeAbstract = 0x00000080;
const int _typeSealed = 0x00000100;

const int _fieldAccessMask = 0x0007;
const int _fieldPrivate = 0x0001;
const int _fieldFamAndAssem = 0x0002;
const int _fieldAssembly = 0x0003;
const int _fieldFamily = 0x0004;
const int _fieldFamOrAssem = 0x0005;
const int _fieldPublic = 0x0006;
const int _fieldStatic = 0x0010;
const int _fieldInitOnly = 0x0020;
const int _fieldLiteral = 0x0040;

const int _methodAccessMask = 0x0007;
const int _methodPrivate = 0x0001;
const int _methodFamAndAssem = 0x0002;
const int _methodAssem = 0x0003;
const int _methodFamily = 0x0004;
const int _methodFamOrAssem = 0x0005;
const int _methodPublic = 0x0006;
const int _methodStatic = 0x0010;
const int _methodFinal = 0x0020;
const int _methodVirtual = 0x0040;
const int _methodVtableMask = 0x0100;
const int _methodNewSlot = 0x0100;
const int _methodAbstract = 0x0400;
const int _methodPInvoke = 0x2000;

const int _paramIn = 0x0001;
const int _paramOut = 0x0002;

DumpResult runDump({
  required String il2cppPath,
  required String metadataPath,
  required String outDir,
  DumpProgress? onProgress,
}) {
  final notes = <String>[];
  final files = <String>[];
  final sw = Stopwatch()..start();
  void prog(String phase, int pct, String detail) {
    if (onProgress != null) onProgress(phase, pct, detail);
  }

  try {
    Directory(outDir).createSync(recursive: true);

    prog('metadata', 4, 'Membaca global-metadata.dat...');
    final metaBytes = File(metadataPath).readAsBytesSync();
    if (metaBytes.length < 64) {
      throw 'File global-metadata.dat kekecilan / rusak.';
    }
    final meta = Metadata.fromFileBytes(Uint8List.fromList(metaBytes));
    prog('metadata', 12,
        'Metadata v${meta.version} | ${meta.typeDefCount} tipe | ${meta.imageDefCount} assembly');

    prog('elf', 18, 'Parsing ELF (libil2cpp.so)...');
    final elf = ElfImage.open(il2cppPath);
    if (elf.protectionWarning != null) notes.add(elf.protectionWarning!);

    final bin = Il2CppBin(elf, meta);
    final names = TypeNames(elf, meta, bin);

    prog('search', 26, 'Mencari CodeRegistration / MetadataRegistration...');
    bool found = bin.symbolSearch();
    if (!found) {
      found = bin.plusSearch();
    }
    if (found) {
      prog('search', 30, 'Refining versi il2cpp...');
      bin.autoPlusInit();
      if (bin.versionChanged) {
        notes.add('Versi il2cpp di-refine ke v${bin.version}.');
      }
    } else {
      notes.add('CodeRegistration/MetadataRegistration gak ketemu — dump parsial '
          '(token only, tanpa RVA & signature tipe).');
    }

    final stats = <String, dynamic>{
      'metadataVersion': meta.version,
      'il2cppVersion': bin.version,
      'typeCount': meta.typeDefCount,
      'methodCount': meta.methodDefCount,
      'fieldCount': meta.fieldDefCount,
      'imageCount': meta.imageDefCount,
      'stringLiteralCount': meta.stringLiteralCount,
      'registrationFound': found,
      'codegenModules': bin.codeGenModules.length,
      'searchLog': bin.searchLog,
    };

    int methodsWithRva = 0;
    int doneTypes = 0;
    final totalTypes = meta.typeDefCount;

    // ---- dump.cs -------------------------------------------------------------
    prog('dump', 36, 'Menulis dump.cs...');
    final dumpPath = '$outDir/dump.cs';
    final dw = _OutWriter(dumpPath);
    files.add(dumpPath);
    try {
      if (!found) {
        dw.wl('// CATATAN: registrasi il2cpp gak ketemu — dump parsial (tanpa RVA/signature).');
      }
      for (int imageIndex = 0; imageIndex < meta.imageDefCount; imageIndex++) {
        final imgName = meta.getStringFromIndex(meta.imgNameIdx[imageIndex]);
        dw.wl('// Image $imageIndex: $imgName - ${meta.imgTypeStart[imageIndex]}');
      }
      for (int imageIndex = 0; imageIndex < meta.imageDefCount; imageIndex++) {
        final imageName = meta.getStringFromIndex(meta.imgNameIdx[imageIndex]);
        final typeStart = meta.imgTypeStart[imageIndex];
        final typeEnd = typeStart + meta.imgTypeCount[imageIndex];
        for (int typeDefIndex = typeStart; typeDefIndex < typeEnd; typeDefIndex++) {
          if (typeDefIndex < 0 || typeDefIndex >= meta.typeDefCount) continue;
          _dumpType(dw, meta, bin, names, imageName, typeDefIndex, found, notes, (n) {
            methodsWithRva += n;
          });
          doneTypes++;
          if (doneTypes % 2000 == 0) {
            prog('dump', 36 + (52 * doneTypes ~/ (totalTypes == 0 ? 1 : totalTypes)),
                'dump.cs: $doneTypes/$totalTypes tipe');
          }
        }
      }
    } catch (e) {
      dw.wl('/* KepinDumper: error parsial di dump.cs: $e */');
    }
    dw.close();

    // ---- stringliteral.txt ----------------------------------------------------
    prog('literal', 90, 'Menulis stringliteral.txt...');
    final litPath = '$outDir/stringliteral.txt';
    final lw = _OutWriter(litPath);
    files.add(litPath);
    try {
      for (int i = 0; i < meta.stringLiteralCount; i++) {
        lw.wl(meta.getStringLiteral(i));
      }
    } catch (_) {}
    lw.close();

    // ---- script.json ----------------------------------------------------------
    prog('script', 94, 'Menulis script.json...');
    final scriptPath = '$outDir/script.json';
    final sjw = _OutWriter(scriptPath);
    files.add(scriptPath);
    try {
      _writeScriptJson(sjw, meta, bin, names, found);
    } catch (_) {}
    sjw.close();

    // ---- info.txt -------------------------------------------------------------
    prog('info', 98, 'Menulis info.txt...');
    final infoPath = '$outDir/info.txt';
    final iw = _OutWriter(infoPath);
    files.add(infoPath);
    stats['methodsWithRva'] = methodsWithRva;
    stats['elapsedMs'] = sw.elapsedMilliseconds;
    iw.wl('KepinDumper v3 — IL2CPP dump report');
    iw.wl('Waktu: ${DateTime.now().toIso8601String()}');
    iw.wl('');
    iw.wl('== Input ==');
    iw.wl('libil2cpp.so        : $il2cppPath (${_fmtSize(File(il2cppPath).lengthSync())})');
    iw.wl('global-metadata.dat : $metadataPath (${_fmtSize(File(metadataPath).lengthSync())})');
    iw.wl('');
    iw.wl('== Versi ==');
    iw.wl('Metadata version : ${meta.version}');
    iw.wl('Il2Cpp version   : ${bin.version}');
    iw.wl('ELF              : ${elf.is32 ? 'ELF32' : 'ELF64'} / machine ${elf.machine}');
    iw.wl('');
    iw.wl('== Statistik ==');
    iw.wl('Images (assembly) : ${meta.imageDefCount}');
    iw.wl('Type definitions   : ${meta.typeDefCount}');
    iw.wl('Methods            : ${meta.methodDefCount}');
    iw.wl('Fields             : ${meta.fieldDefCount}');
    iw.wl('String literals    : ${meta.stringLiteralCount}');
    iw.wl('Methods with RVA   : $methodsWithRva / ${meta.methodDefCount}');
    iw.wl('CodeGen modules    : ${bin.codeGenModules.length}');
    iw.wl('Registration found : $found');
    iw.wl('');
    iw.wl('== Catatan ==');
    for (final n in notes) {
      iw.wl('- $n');
    }
    if (bin.codeGenModules.isNotEmpty) {
      iw.wl('');
      iw.wl('== CodeGen modules ==');
      var i = 0;
      for (final k in bin.codeGenModules.keys) {
        if (i++ >= 60) {
          iw.wl('... (${bin.codeGenModules.length - 60} lagi)');
          break;
        }
        final m = bin.codeGenModules[k]!;
        iw.wl('- $k (methodPointers: ${m.methodPointerCount})');
      }
    }
    iw.close();

    elf.file.close();
    prog('done', 100, 'Selesai dalam ${(sw.elapsedMilliseconds / 1000).toStringAsFixed(1)}s');
    return DumpResult(true, null, outDir, files, stats);
  } catch (e) {
    try {
      prog('error', 100, 'GAGAL: $e');
    } catch (_) {}
    return DumpResult(false, e.toString(), outDir, files, const <String, dynamic>{});
  }
}

String _fmtSize(int bytes) {
  if (bytes > 1024 * 1024 * 1024) return '${(bytes / 1024 / 1024 / 1024).toStringAsFixed(2)} GB';
  if (bytes > 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)} MB';
  if (bytes > 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
  return '$bytes B';
}

String _methodModifiers(int flags) {
  var s = '';
  switch (flags & _methodAccessMask) {
    case _methodPrivate:
      s += 'private ';
      break;
    case _methodPublic:
      s += 'public ';
      break;
    case _methodFamily:
      s += 'protected ';
      break;
    case _methodAssem:
    case _methodFamAndAssem:
      s += 'internal ';
      break;
    case _methodFamOrAssem:
      s += 'protected internal ';
      break;
  }
  if ((flags & _methodStatic) != 0) s += 'static ';
  if ((flags & _methodAbstract) != 0) {
    s += 'abstract ';
    if ((flags & _methodVtableMask) == 0) s += 'override ';
  } else if ((flags & _methodFinal) != 0) {
    if ((flags & _methodVtableMask) == 0) s += 'sealed override ';
  } else if ((flags & _methodVirtual) != 0) {
    if ((flags & _methodVtableMask) == _methodNewSlot) {
      s += 'virtual ';
    } else {
      s += 'override ';
    }
  }
  if ((flags & _methodPInvoke) != 0) s += 'extern ';
  return s;
}

void _dumpType(
  _OutWriter dw,
  Metadata meta,
  Il2CppBin bin,
  TypeNames names,
  String imageName,
  int typeDefIndex,
  bool hasTypes,
  List<String> notes,
  void Function(int) onMethodWithRva,
) {
  final extendsList = <String>[];
  final parentIdx = meta.tdParent[typeDefIndex];
  if (parentIdx >= 0 && hasTypes) {
    final parentName = names.byTypeIndex(parentIdx);
    if (!meta.typeIsValueType(typeDefIndex) && !meta.typeIsEnum(typeDefIndex) && parentName != 'object') {
      extendsList.add(parentName);
    }
  }
  final ifCount = meta.tdInterfacesCount[typeDefIndex];
  if (ifCount > 0 && hasTypes) {
    final start = meta.tdInterfacesStart[typeDefIndex];
    for (int i = 0; i < ifCount && i < 256; i++) {
      final off = start + i;
      if (off < 0 || off >= meta.interfaceIndicesCount) break;
      extendsList.add(names.byTypeIndex(meta.interfaceIndices[off]));
    }
  }

  dw.wl();
  dw.wl('// Namespace: ${meta.getStringFromIndex(meta.tdNamespaceIdx[typeDefIndex])}');

  final flags = meta.tdFlags[typeDefIndex];
  final sb = StringBuffer();
  switch (flags & _typeVisibilityMask) {
    case _typePublic:
    case _typeNestedPublic:
      sb.write('public ');
      break;
    case 0:
    case _typeNestedFamAndAssem:
    case _typeNestedAssembly:
      sb.write('internal ');
      break;
    case _typeNestedPrivate:
      sb.write('private ');
      break;
    case _typeNestedFamily:
      sb.write('protected ');
      break;
    case _typeNestedFamOrAssem:
      sb.write('protected internal ');
      break;
  }
  final isValueType = meta.typeIsValueType(typeDefIndex);
  final isEnum = meta.typeIsEnum(typeDefIndex);
  if ((flags & _typeAbstract) != 0 && (flags & _typeSealed) != 0) {
    sb.write('static ');
  } else if ((flags & _typeInterface) == 0 && (flags & _typeAbstract) != 0) {
    sb.write('abstract ');
  } else if (!isValueType && !isEnum && (flags & _typeSealed) != 0) {
    sb.write('sealed ');
  }
  if ((flags & _typeInterface) != 0) {
    sb.write('interface ');
  } else if (isEnum) {
    sb.write('enum ');
  } else if (isValueType) {
    sb.write('struct ');
  } else {
    sb.write('class ');
  }
  sb.write(names.typeDefName(typeDefIndex, genericParameter: true));
  if (extendsList.isNotEmpty) {
    sb.write(' : ${extendsList.join(', ')}');
  }
  sb.write(' // TypeDefIndex: $typeDefIndex');
  dw.wl(sb.toString());
  dw.wl('{');

  // Fields
  final fCount = meta.tdFieldCount[typeDefIndex];
  if (fCount > 0) {
    dw.wl('\t// Fields');
    final fStart = meta.tdFieldStart[typeDefIndex];
    for (int i = fStart; i < fStart + fCount; i++) {
      if (i < 0 || i >= meta.fieldDefCount) break;
      var line = StringBuffer('\t');
      var isStatic = false;
      var isConst = false;
      if (hasTypes) {
        final e = _safeEntry(bin, meta.fdTypeIndex[i]);
        final attrs = e == null ? 0 : (e.bits & 0xFFFF);
        switch (attrs & _fieldAccessMask) {
          case _fieldPrivate:
            line.write('private ');
            break;
          case _fieldPublic:
            line.write('public ');
            break;
          case _fieldFamily:
            line.write('protected ');
            break;
          case _fieldAssembly:
          case _fieldFamAndAssem:
            line.write('internal ');
            break;
          case _fieldFamOrAssem:
            line.write('protected internal ');
            break;
        }
        if ((attrs & _fieldLiteral) != 0) {
          isConst = true;
          line.write('const ');
        } else {
          if ((attrs & _fieldStatic) != 0) {
            isStatic = true;
            line.write('static ');
          }
          if ((attrs & _fieldInitOnly) != 0) {
            line.write('readonly ');
          }
        }
        line.write(names.byTypeIndex(meta.fdTypeIndex[i]));
      }
      line.write(' ${meta.getStringFromIndex(meta.fdNameIdx[i])}');
      if (isConst) {
        line.write(';');
      } else {
        final off = bin.getFieldOffsetFromIndex(typeDefIndex, i - fStart, i, isValueType, isStatic);
        line.write('; // 0x${_hex(off < 0 ? 0 : off)}');
      }
      dw.wl(line.toString());
    }
  }

  // Properties
  final pCount = meta.tdPropertyCount[typeDefIndex];
  if (pCount > 0) {
    dw.wl('\t// Properties');
    final pStart = meta.tdPropertyStart[typeDefIndex];
    final mStart = meta.tdMethodStart[typeDefIndex];
    for (int i = pStart; i < pStart + pCount; i++) {
      if (i < 0 || i >= meta.propertyDefCount) break;
      final line = StringBuffer('\t');
      if (hasTypes) {
        int getter = meta.propGet[i];
        int setter = meta.propSet[i];
        int via = getter >= 0 ? getter : setter;
        if (via < 0) via = 0;
        final md = mStart + via;
        if (md >= 0 && md < meta.methodDefCount) {
          line.write(_methodModifiers(meta.mdFlags[md]));
          if (getter >= 0) {
            line.write(names.byTypeIndex(meta.mdReturnType[md]));
          } else {
            final pd = meta.mdParameterStart[md];
            if (pd >= 0 && pd < meta.paramDefCount) {
              line.write(names.byTypeIndex(meta.pdTypeIndex[pd]));
            }
          }
        }
      }
      line.write(' ${meta.getStringFromIndex(meta.propNameIdx[i])} { ');
      if (meta.propGet[i] >= 0) line.write('get; ');
      if (meta.propSet[i] >= 0) line.write('set; ');
      line.write('}');
      dw.wl(line.toString());
    }
  }

  // Methods
  final mCount = meta.tdMethodCount[typeDefIndex];
  if (mCount > 0) {
    dw.wl('\t// Methods');
    final mStart = meta.tdMethodStart[typeDefIndex];
    for (int i = mStart; i < mStart + mCount; i++) {
      if (i < 0 || i >= meta.methodDefCount) break;
      dw.wl();
      final flags = meta.mdFlags[i];
      final isAbstract = (flags & _methodAbstract) != 0;
      var methodPointer = 0;
      try {
        methodPointer = bin.getMethodPointer(imageName, i);
      } catch (_) {}
      if (!isAbstract && methodPointer > 0) {
        final rva = bin.getRVA(methodPointer);
        final offset = bin.elf.mapVATR(methodPointer);
        dw.wl('\t// RVA: 0x${_hex(rva)} Offset: 0x${_hex(offset < 0 ? 0 : offset)} VA: 0x${_hex(methodPointer)}');
        onMethodWithRva(1);
      } else {
        dw.wl('\t// RVA: -1 Offset: -1');
      }
      if (meta.mdSlot[i] != 0xFFFF) {
        dw.w('\t// Slot: ${meta.mdSlot[i]}\n');
      }

      final line = StringBuffer('\t');
      line.write(_methodModifiers(flags));
      var methodName = meta.getStringFromIndex(meta.mdNameIdx[i]);
      final gci = meta.mdGenericContainer[i];
      if (gci >= 0) {
        methodName += names.genericContainerParams(gci);
      }
      if (hasTypes) {
        final retEntry = _safeEntry(bin, meta.mdReturnType[i]);
        if (retEntry != null && names.entryIsByref(retEntry)) {
          line.write('ref ');
        }
        line.write(names.byTypeIndex(meta.mdReturnType[i]));
      } else {
        line.write('void');
      }
      line.write(' $methodName(');
      final pStart = meta.mdParameterStart[i];
      final pCount = meta.mdParameterCount[i];
      final pStrs = <String>[];
      for (int j = 0; j < pCount; j++) {
        final pd = pStart + j;
        if (pd < 0 || pd >= meta.paramDefCount) break;
        var ps = StringBuffer();
        if (hasTypes) {
          final entry = _safeEntry(bin, meta.pdTypeIndex[pd]);
          if (entry != null && names.entryIsByref(entry)) {
            final attrs = entry.bits & 0xFFFF;
            if ((attrs & _paramOut) != 0 && (attrs & _paramIn) == 0) {
              ps.write('out ');
            } else if ((attrs & _paramOut) == 0 && (attrs & _paramIn) != 0) {
              ps.write('in ');
            } else {
              ps.write('ref ');
            }
          } else {
            final attrs = entry == null ? 0 : entry.bits & 0xFFFF;
            if ((attrs & _paramIn) != 0) ps.write('[In] ');
            if ((attrs & _paramOut) != 0) ps.write('[Out] ');
          }
          ps.write(names.byTypeIndex(meta.pdTypeIndex[pd]));
        }
        ps.write(' ${meta.getStringFromIndex(meta.pdNameIdx[pd])}');
        pStrs.add(ps.toString());
      }
      line.write(pStrs.join(', '));
      if (isAbstract) {
        line.write(');');
      } else {
        line.write(') { }');
      }
      dw.wl(line.toString());

      // blok GenericInstMethod
      final specs = bin.methodDefinitionMethodSpecs[i];
      if (specs != null && specs.isNotEmpty) {
        dw.wl('\t/* GenericInstMethod :');
        for (final gmi in specs) {
          dw.wl('\t|');
          final ptr = bin.methodSpecPointer(gmi);
          if (ptr > 0) {
            final off = bin.elf.mapVATR(ptr);
            dw.wl('\t|-RVA: 0x${_hex(bin.getRVA(ptr))} Offset: 0x${_hex(off < 0 ? 0 : off)} VA: 0x${_hex(ptr)}');
          } else {
            dw.wl('\t|-RVA: -1 Offset: -1');
          }
          final mdIdx = bin.specMd[gmi];
          String tName = '';
          String mName = '';
          if (mdIdx >= 0 && mdIdx < meta.methodDefCount) {
            final declIdx = meta.mdDeclaringType[mdIdx];
            if (declIdx >= 0 && declIdx < meta.typeDefCount) {
              tName = names.typeDefName(declIdx);
            }
            mName = meta.getStringFromIndex(meta.mdNameIdx[mdIdx]);
          }
          final clsIdx = bin.specClass[gmi];
          if (clsIdx >= 0 && clsIdx < bin.genericInstPtrs.length) {
            tName += _genericInstParams(bin, names, clsIdx);
          }
          final mthIdx = bin.specMethod[gmi];
          if (mthIdx >= 0 && mthIdx < bin.genericInstPtrs.length) {
            mName += _genericInstParams(bin, names, mthIdx);
          }
          dw.wl('\t|-$tName.$mName');
        }
        dw.wl('\t*/');
      }
    }
  }

  dw.wl('}');
}

Il2CppTypeEntry? _safeEntry(Il2CppBin bin, int typeIndex) {
  if (typeIndex < 0 || typeIndex >= bin.typesCount) return null;
  if (bin.types.length != bin.typesCount) return null;
  return bin.types[typeIndex];
}

String _genericInstParams(Il2CppBin bin, TypeNames names, int instIndex) {
  try {
    final ptr = bin.genericInstPtrs[instIndex];
    final off = bin.elf.mapVATR(ptr);
    if (off == 0) return '';
    final argc = bin.elf.file.ptrAt(off);
    final argv = bin.elf.file.ptrAt(off + bin.elf.pointerSize);
    if (argc <= 0 || argc >= 64 || argv == 0) return '';
    final argvOff = bin.elf.mapVATR(argv);
    if (argvOff == 0) return '';
    final sb = StringBuffer('<');
    for (int i = 0; i < argc; i++) {
      if (i > 0) sb.write(', ');
      final p = bin.elf.file.ptrAt(argvOff + i * bin.elf.pointerSize);
      sb.write(names.fromEntry(names.typeByPtrPublic(p)));
    }
    sb.write('>');
    return sb.toString();
  } catch (_) {
    return '';
  }
}

void _writeScriptJson(_OutWriter sjw, Metadata meta, Il2CppBin bin, TypeNames names, bool hasTypes) {
  sjw.w('{');
  sjw.w('"generator":"KepinDumper v3",');
  sjw.w('"metadataVersion":${meta.version.toString()},');
  sjw.w('"il2cppVersion":${bin.version.toString()},');
  sjw.w('"images":[');
  for (int i = 0; i < meta.imageDefCount; i++) {
    if (i > 0) sjw.w(',');
    sjw.w('{"name":"${_jsonEscape(meta.getStringFromIndex(meta.imgNameIdx[i]))}",'
        '"typeStart":${meta.imgTypeStart[i]},"typeCount":${meta.imgTypeCount[i]}}');
  }
  sjw.w('],');
  sjw.w('"types":[');
  bool firstType = true;
  for (int t = 0; t < meta.typeDefCount; t++) {
    final sb = StringBuffer();
    if (!firstType) sb.write(',');
    firstType = false;
    sb.write('{');
    sb.write('"name":"${_jsonEscape(meta.getStringFromIndex(meta.tdNameIdx[t]))}",');
    sb.write('"namespace":"${_jsonEscape(meta.getStringFromIndex(meta.tdNamespaceIdx[t]))}",');
    sb.write('"token":${meta.tdToken[t]},');
    // fields
    sb.write('"fields":[');
    final fStart = meta.tdFieldStart[t];
    final fCount = meta.tdFieldCount[t];
    for (int i = fStart; i < fStart + fCount; i++) {
      if (i < 0 || i >= meta.fieldDefCount) break;
      if (i > fStart) sb.write(',');
      final off = bin.getFieldOffsetFromIndex(t, i - fStart, i, meta.typeIsValueType(t), false);
      sb.write('{"name":"${_jsonEscape(meta.getStringFromIndex(meta.fdNameIdx[i]))}",'
          '"token":${meta.fdToken[i]},"offset":${off < 0 ? -1 : off}}');
    }
    sb.write('],');
    // methods
    sb.write('"methods":[');
    final mStart = meta.tdMethodStart[t];
    final mCount = meta.tdMethodCount[t];
    var imgName = '';
    // cari image yang punya type ini
    for (int k = 0; k < meta.imageDefCount; k++) {
      final s = meta.imgTypeStart[k];
      if (t >= s && t < s + meta.imgTypeCount[k]) {
        imgName = meta.getStringFromIndex(meta.imgNameIdx[k]);
        break;
      }
    }
    for (int i = mStart; i < mStart + mCount; i++) {
      if (i < 0 || i >= meta.methodDefCount) break;
      if (i > mStart) sb.write(',');
      var va = 0;
      try {
        va = bin.getMethodPointer(imgName, i);
      } catch (_) {}
      sb.write('{"name":"${_jsonEscape(meta.getStringFromIndex(meta.mdNameIdx[i]))}",'
          '"token":${meta.mdToken[i]},"va":$va}');
    }
    sb.write(']');
    sb.write('}');
    sjw.w(sb.toString());
    if (t % 4096 == 0) {
      // flush berkala biar memori aman
      sjw.w('');
    }
  }
  sjw.w(']');
  sjw.w('}');
}
