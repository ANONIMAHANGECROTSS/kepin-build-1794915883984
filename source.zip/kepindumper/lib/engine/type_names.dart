// KepinDumper engine: Il2CppType name resolution.
// Port of Il2CppExecutor (GetTypeName / GetTypeDefName / generic params).

import 'elf.dart';
import 'metadata.dart';
import 'registration.dart';

// Il2CppTypeEnum: (bits >> 16) & 0xFF
const int kTypeVoid = 0x01;
const int kTypeBoolean = 0x02;
const int kTypeChar = 0x03;
const int kTypeI1 = 0x04;
const int kTypeU1 = 0x05;
const int kTypeI2 = 0x06;
const int kTypeU2 = 0x07;
const int kTypeI4 = 0x08;
const int kTypeU4 = 0x09;
const int kTypeI8 = 0x0a;
const int kTypeU8 = 0x0b;
const int kTypeR4 = 0x0c;
const int kTypeR8 = 0x0d;
const int kTypeString = 0x0e;
const int kTypePtr = 0x0f;
const int kTypeByref = 0x10;
const int kTypeValuetype = 0x11;
const int kTypeClass = 0x12;
const int kTypeVar = 0x13;
const int kTypeArray = 0x14;
const int kTypeGenericinst = 0x15;
const int kTypeTypedbyref = 0x16;
const int kTypeI = 0x18;
const int kTypeU = 0x19;
const int kTypeFnptr = 0x1b;
const int kTypeObject = 0x1c;
const int kTypeSzarray = 0x1d;
const int kTypeMvar = 0x1e;

const Map<int, String> _primitiveNames = {
  kTypeVoid: 'void',
  kTypeBoolean: 'bool',
  kTypeChar: 'char',
  kTypeI1: 'sbyte',
  kTypeU1: 'byte',
  kTypeI2: 'short',
  kTypeU2: 'ushort',
  kTypeI4: 'int',
  kTypeU4: 'uint',
  kTypeI8: 'long',
  kTypeU8: 'ulong',
  kTypeR4: 'float',
  kTypeR8: 'double',
  kTypeString: 'string',
  kTypeTypedbyref: 'TypedReference',
  kTypeI: 'IntPtr',
  kTypeU: 'UIntPtr',
  kTypeObject: 'object',
};

class TypeNames {
  final ElfImage elf;
  final Metadata meta;
  final Il2CppBin bin;
  final Map<int, String> _byIndexCache = {};

  TypeNames(this.elf, this.meta, this.bin);

  bool get hasTypes => bin.typesCount > 0 && bin.types.length == bin.typesCount;

  Il2CppTypeEntry? _entryAt(int typeIndex) {
    if (typeIndex < 0 || typeIndex >= bin.typesCount || !hasTypes) return null;
    return bin.types[typeIndex];
  }

  /// Nama tipe dari index tabel Il2CppType (return type / param / field / parent).
  String byTypeIndex(int typeIndex) {
    if (typeIndex < 0) return 'void';
    final cached = _byIndexCache[typeIndex];
    if (cached != null) return cached;
    final e = _entryAt(typeIndex);
    final result = e == null ? 'object' : fromEntry(e);
    _byIndexCache[typeIndex] = result;
    return result;
  }

  Il2CppTypeEntry _typeByPtr(int ptr) {
    if (ptr == 0) return const Il2CppTypeEntry(0, 0);
    final known = bin.getTypeByPtr(ptr);
    if (known != null) return known;
    final off = elf.mapVATR(ptr);
    if (off == 0) return const Il2CppTypeEntry(0, 0);
    return Il2CppTypeEntry(elf.file.ptrAt(off), elf.file.u32At(off + elf.pointerSize));
  }

  /// Akses publik untuk engine lain (blok GenericInstMethod).
  Il2CppTypeEntry typeByPtrPublic(int ptr) => _typeByPtr(ptr);

  String fromEntry(Il2CppTypeEntry e) {
    switch ((e.bits >> 16) & 0xFF) {
      case kTypeArray:
        {
          final arrOff = elf.mapVATR(e.data);
          if (arrOff == 0) return 'object';
          final etypePtr = elf.file.ptrAt(arrOff);
          final rank = elf.file.u32At(arrOff + 8) & 0xFF;
          final inner = _typeByPtr(etypePtr);
          final commas = rank > 9 ? 8 : (rank < 1 ? 0 : rank - 1);
          final sb = StringBuffer()..write(fromEntry(inner))..write('[');
          for (int i = 0; i < commas; i++) {
            sb.write(',');
          }
          sb.write(']');
          return sb.toString();
        }
      case kTypeSzarray:
        return '${fromEntry(_typeByPtr(e.data))}[]';
      case kTypePtr:
        return '${fromEntry(_typeByPtr(e.data))}*';
      case kTypeVar:
      case kTypeMvar:
        {
          final idx = e.data;
          if (idx >= 0 && idx < meta.genericParameterCount) {
            return meta.getStringFromIndex(meta.gpNameIdx[idx]);
          }
          return 'T';
        }
      case kTypeClass:
      case kTypeValuetype:
      case kTypeGenericinst:
        return _classLikeName(e, false);
      default:
        return _primitiveNames[(e.bits >> 16) & 0xFF] ?? 'object';
    }
  }

  /// Nama class/struct/generic. [isNested] memotong generic args (persis
  /// GetTypeName(is_nested) di referensi).
  String _classLikeName(Il2CppTypeEntry e, bool isNested) {
    final t = (e.bits >> 16) & 0xFF;
    int typeDefIndex = -1;
    int genericClassPtr = 0;
    if (t == kTypeGenericinst) {
      genericClassPtr = e.data;
      final gcOff = elf.mapVATR(genericClassPtr);
      if (gcOff == 0) return 'object';
      if (bin.version <= 24.5) {
        final tdi = elf.file.ptrAt(gcOff);
        if (tdi >= 0 && tdi < meta.typeDefCount) typeDefIndex = tdi;
      } else {
        final typePtr = elf.file.ptrAt(gcOff);
        final inner = _typeByPtr(typePtr);
        final idx = inner.data;
        if (idx >= 0 && idx < meta.typeDefCount) typeDefIndex = idx;
      }
    } else {
      final idx = e.data;
      if (idx >= 0 && idx < meta.typeDefCount) typeDefIndex = idx;
    }
    if (typeDefIndex < 0) return 'object';

    final sb = StringBuffer();
    final declaring = meta.tdDeclaring[typeDefIndex];
    if (declaring != -1 && declaring >= 0) {
      final dEntry = _entryAt(declaring);
      if (dEntry != null) {
        sb.write(_classLikeName(dEntry, true));
      } else {
        sb.write(typeDefBaseName(_declaringFallback(declaring, typeDefIndex)));
      }
      sb.write('.');
    } else {
      final ns = meta.getStringFromIndex(meta.tdNamespaceIdx[typeDefIndex]);
      if (ns.isNotEmpty) {
        sb.write(ns);
        sb.write('.');
      }
    }

    var typeName = meta.getStringFromIndex(meta.tdNameIdx[typeDefIndex]);
    final backtick = typeName.indexOf('`');
    if (backtick != -1) typeName = typeName.substring(0, backtick);
    sb.write(typeName);

    if (isNested) return sb.toString();

    if (genericClassPtr != 0) {
      final gcOff = elf.mapVATR(genericClassPtr);
      if (gcOff != 0) {
        final classInstPtr = elf.file.ptrAt(gcOff + elf.pointerSize); // context.class_inst
        final giOff = elf.mapVATR(classInstPtr);
        if (giOff != 0) {
          final argc = elf.file.ptrAt(giOff);
          final argv = elf.file.ptrAt(giOff + elf.pointerSize);
          if (argc > 0 && argc < 64 && argv != 0) {
            sb.write('<');
            final argvOff = elf.mapVATR(argv);
            if (argvOff != 0) {
              for (int i = 0; i < argc; i++) {
                if (i > 0) sb.write(', ');
                final p = elf.file.ptrAt(argvOff + i * elf.pointerSize);
                sb.write(fromEntry(_typeByPtr(p)));
              }
            }
            sb.write('>');
          }
        }
      }
    } else if (meta.tdGenericContainer[typeDefIndex] >= 0) {
      sb.write(genericContainerParams(meta.tdGenericContainer[typeDefIndex]));
    }
    return sb.toString();
  }

  /// Kalau tabel runtime types gak ada (registrasi gagal), nama parent nested
  /// dicari manual via kolom declaring (fallback longgar).
  int _declaringFallback(int declaringTypeIndex, int selfIndex) {
    for (int i = 0; i < meta.typeDefCount; i++) {
      if (meta.tdByval[i] == declaringTypeIndex) return i;
    }
    return selfIndex;
  }

  String typeDefBaseName(int typeDefIndex) {
    final sb = StringBuffer();
    final ns = meta.getStringFromIndex(meta.tdNamespaceIdx[typeDefIndex]);
    if (ns.isNotEmpty) {
      sb.write(ns);
      sb.write('.');
    }
    var typeName = meta.getStringFromIndex(meta.tdNameIdx[typeDefIndex]);
    final backtick = typeName.indexOf('`');
    if (backtick != -1) typeName = typeName.substring(0, backtick);
    sb.write(typeName);
    return sb.toString();
  }

  /// Nama lengkap typeDef (dipakai buat deklarasi class di dump.cs).
  String typeDefName(int typeDefIndex, {bool genericParameter = false}) {
    final sb = StringBuffer();
    final declaring = meta.tdDeclaring[typeDefIndex];
    if (declaring != -1 && declaring >= 0) {
      final dEntry = _entryAt(declaring);
      if (dEntry != null) {
        sb.write(_classLikeName(dEntry, true));
      } else {
        sb.write(typeDefName(_declaringFallback(declaring, typeDefIndex)));
      }
      sb.write('.');
    } else {
      final ns = meta.getStringFromIndex(meta.tdNamespaceIdx[typeDefIndex]);
      if (ns.isNotEmpty) {
        sb.write(ns);
        sb.write('.');
      }
    }
    var typeName = meta.getStringFromIndex(meta.tdNameIdx[typeDefIndex]);
    final gc = meta.tdGenericContainer[typeDefIndex];
    if (gc >= 0) {
      final backtick = typeName.indexOf('`');
      if (backtick != -1) typeName = typeName.substring(0, backtick);
      if (genericParameter) {
        typeName += genericContainerParams(gc);
      }
    }
    sb.write(typeName);
    return sb.toString();
  }

  String genericContainerParams(int containerIndex) {
    if (containerIndex < 0 || containerIndex >= meta.genericContainerCount) return '';
    final argc = meta.gcTypeArgc[containerIndex];
    final start = meta.gcGenericParameterStart[containerIndex];
    if (argc <= 0 || argc > 64) return '';
    final sb = StringBuffer()..write('<');
    for (int i = 0; i < argc; i++) {
      if (i > 0) sb.write(', ');
      final gp = start + i;
      if (gp >= 0 && gp < meta.genericParameterCount) {
        sb.write(meta.getStringFromIndex(meta.gpNameIdx[gp]));
      } else {
        sb.write('T');
      }
    }
    sb.write('>');
    return sb.toString();
  }

  bool entryIsByref(Il2CppTypeEntry e) {
    if (bin.version >= 27.2) return ((e.bits >> 29) & 1) == 1;
    return ((e.bits >> 30) & 1) == 1;
  }
}
