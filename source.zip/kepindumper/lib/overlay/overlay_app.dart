// KepinDumper: GUI overlay melayang — draggable, deteksi paket, tombol DUMP.
// Dijalankan engine terpisah lewat entry point overlayMain().

import 'dart:async';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import '../core/palette.dart';
import '../core/native_shell.dart';
import '../core/apk_zip.dart';
import '../core/dump_runner.dart';

class OverlayApp extends StatefulWidget {
  const OverlayApp({super.key});
  @override
  State<OverlayApp> createState() => _OverlayAppState();
}

class _OverlayAppState extends State<OverlayApp> {
  String? _pkg;
  bool _rootOk = false;
  bool _dumping = false;
  double _pct = 0;
  String _status = '';
  String _result = '';
  Timer? _poll;

  static const _libEntries = ['lib/arm64-v8a/libil2cpp.so', 'lib/armeabi-v7a/libil2cpp.so'];
  static const _mdEntry = 'assets/bin/Data/Managed/Metadata/global-metadata.dat';
  static const _outBase = '/storage/emulated/0/KepinDumper';

  @override
  void initState() {
    super.initState();
    _status = 'cek root…';
    _init();
  }

  Future<void> _init() async {
    final root = await NativeShell.hasRoot();
    if (!mounted) return;
    setState(() {
      _rootOk = root;
      _status = root ? 'buka game yang mau di-dump' : 'ROOT BUTUH — su gak ketemu';
    });
    if (root) {
      _poll = Timer.periodic(const Duration(seconds: 2), (_) => _pollPackage());
      _pollPackage();
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    super.dispose();
  }

  Future<void> _pollPackage() async {
    if (_dumping) return;
    final pkg = await NativeShell.foregroundPackage();
    if (!mounted || _dumping) return;
    if (pkg != _pkg) {
      setState(() {
        _pkg = pkg;
        if (pkg != null && _rootOk) _status = 'target siap — tekan DUMP';
      });
    }
  }

  Future<void> _dump() async {
    if (_dumping) return;
    final pkg = _pkg;
    if (pkg == null) {
      setState(() => _status = 'buka game dulu (target belum kedeteksi)');
      return;
    }
    setState(() {
      _dumping = true;
      _result = '';
      _pct = 0;
      _status = 'mencari APK…';
    });
    _poll?.cancel();
    try {
      final apks = await NativeShell.apkPaths(pkg);
      if (apks.isEmpty) {
        setState(() {
          _dumping = false;
          _status = 'gak nemu APK dari pm path';
        });
        _resumePoll();
        return;
      }
      final ts = DateTime.now();
      final stamp = '${ts.year}${ts.month.toString().padLeft(2, '0')}${ts.day.toString().padLeft(2, '0')}_'
          '${ts.hour.toString().padLeft(2, '0')}${ts.minute.toString().padLeft(2, '0')}${ts.second.toString().padLeft(2, '0')}';
      final tmp = '$_outBase/_tmp/$pkg';
      final outDir = '$_outBase/$pkg\_$stamp';
      Directory(tmp).createSync(recursive: true);

      _set('ekstrak libil2cpp.so…', 0.05);
      final libPath = await _extractMember(apks, _libEntries, tmp, 'libil2cpp.so');
      if (libPath == null) {
        throw 'libil2cpp.so gak ketemu di APK (bukan game il2cpp?)';
      }
      _set('ekstrak global-metadata.dat…', 0.12);
      final mdPath = await _extractMember(apks, [_mdEntry], tmp, 'global-metadata.dat');
      if (mdPath == null) {
        throw 'global-metadata.dat gak ketemu di APK';
      }

      _set('engine dump jalan…', 0.16);
      final res = await DumpRunner.start(
        il2cppPath: libPath,
        metadataPath: mdPath,
        outDir: outDir,
        onProgress: (m) {
          _set(m.detail.isEmpty ? m.phase : m.detail, 0.16 + (m.pct / 100) * 0.8);
        },
      );
      // bersihin tmp
      try {
        Directory(tmp).deleteSync(recursive: true);
      } catch (_) {}
      if (res['ok'] == true) {
        final s = (res['stats'] as Map).cast<String, dynamic>();
        final types = s['typeCount'] ?? '?';
        final methods = s['methodCount'] ?? '?';
        final rva = s['methodsWithRva'] ?? 0;
        setState(() {
          _dumping = false;
          _pct = 1;
          _result = '$types tipe · $methods method · $rva RVA → $outDir';
          _status = 'DUMP BERES — cek folder KepinDumper';
        });
      } else {
        setState(() {
          _dumping = false;
          _status = 'gagal: ${res['error']}';
        });
      }
    } catch (e) {
      setState(() {
        _dumping = false;
        _status = 'gagal: $e';
      });
    }
    _resumePoll();
  }

  void _resumePoll() {
    if (_rootOk) {
      _poll = Timer.periodic(const Duration(seconds: 2), (_) => _pollPackage());
    }
  }

  void _set(String s, double p) {
    if (mounted) {
      setState(() {
        _status = s;
        _pct = p;
      });
    }
  }

  /// Ekstrak anggota dari daftar APK: coba baca langsung (non-root),
  /// lalu unzip -p via root, terakhir copy APK ke tmp lalu parse.
  Future<String?> _extractMember(List<String> apks, List<String> entries, String tmp, String baseName) async {
    final out = '$tmp/$baseName';
    // 1. direct read
    for (final apk in apks) {
      final zip = await ApkZip.open(apk);
      if (zip == null) continue;
      for (final e in entries) {
        final info = zip.find(e);
        if (info == null) continue;
        final ok = await zip.extract(info, out);
        zip.close();
        if (ok) return out;
      }
      zip.close();
    }
    // 2. root unzip -p
    for (final apk in apks) {
      for (final e in entries) {
        final ok = await NativeShell.rootUnzipMember(apk, e, out);
        if (ok) {
          try {
            if (File(out).lengthSync() > 4096) return out;
          } catch (_) {}
        }
      }
    }
    // 3. copy base.apk lalu parse (paling lambat, paling kuat)
    for (final apk in apks) {
      final copy = '$tmp/_apk.zip';
      final ok = await NativeShell.rootCopy(apk, copy);
      if (!ok) continue;
      try {
        final zip = await ApkZip.open(copy);
        if (zip != null) {
          for (final e in entries) {
            final info = zip.find(e);
            if (info == null) continue;
            final ext = await zip.extract(info, out);
            if (ext) {
              zip.close();
              return out;
            }
          }
          zip.close();
        }
      } catch (_) {}
      try {
        File(copy).deleteSync();
      } catch (_) {}
    }
    return null;
  }

  Future<void> _close() async {
    try {
      await FlutterOverlayWindow.closeOverlay();
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    final ready = _rootOk && _pkg != null;
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true),
      home: Scaffold(
        backgroundColor: Colors.transparent,
        body: Center(
          child: Container(
            margin: const EdgeInsets.all(8),
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            decoration: BoxDecoration(
              color: kBgDeep.withOpacity(0.94),
              borderRadius: BorderRadius.circular(22),
              border: Border.all(color: kStrokeHi, width: 1),
              boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 26, offset: const Offset(0, 10))],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Icon(Icons.drag_indicator_rounded, color: kFaint, size: 16),
                    const SizedBox(width: 4),
                    Text('KEPIN DUMPER', style: kDisplay(size: 12, w: FontWeight.w700, c: kLime, ls: 1.8)),
                    const Spacer(),
                    KTap(
                      onTap: _close,
                      child: const Icon(Icons.close_rounded, color: kFaint, size: 16),
                    ),
                  ],
                ),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    color: kSurface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: _pkg != null ? kLime.withOpacity(0.35) : kStroke),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('TARGET', style: kMono(size: 8, c: kFaint, ls: 1.8)),
                      const SizedBox(height: 3),
                      Text(
                        _pkg ?? '— belum kedeteksi —',
                        style: kMono(size: 10, w: FontWeight.w700, c: _pkg != null ? kText : kFaint),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  _status,
                  style: kMono(size: 9, c: _status.startsWith('DUMP BERES') ? kMint : kDim),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 8),
                if (_dumping)
                  KBar(value: _pct, height: 5)
                else
                  KTap(
                    onTap: _dump,
                    child: Container(
                      width: double.infinity,
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: ready ? kLime : kSurfaceHi,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: ready ? [BoxShadow(color: kLime.withOpacity(0.3), blurRadius: 12)] : null,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.bolt_rounded, size: 15, color: ready ? kBgDeep : kFaint),
                          const SizedBox(width: 7),
                          Text(
                            'DUMP',
                            style: kDisplay(size: 12, w: FontWeight.w700, c: ready ? kBgDeep : kFaint, ls: 2.2),
                          ),
                        ],
                      ),
                    ),
                  ),
                if (_result.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(
                    _result,
                    style: kMono(size: 8, c: kMint),
                    maxLines: 3,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }
}
