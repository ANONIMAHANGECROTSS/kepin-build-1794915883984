// KepinDumper: ZIP (APK) reader via central directory — streaming, low-memory.
// Dipakai buat baca libil2cpp.so + global-metadata.dat dari APK game.

import 'dart:convert' show ZLibDecoder;
import 'dart:io';
import 'dart:typed_data';

class ZipEntryInfo {
  final String name;
  final int method;
  final int compressedSize;
  final int uncompressedSize;
  final int localOffset;
  const ZipEntryInfo(this.name, this.method, this.compressedSize, this.uncompressedSize, this.localOffset);
}

class ApkZip {
  final String path;
  final RandomAccessFile _raf;
  final List<ZipEntryInfo> entries = [];
  final Map<String, ZipEntryInfo> _byName = {};

  ApkZip._(this.path, this._raf);

  static Future<ApkZip?> open(String path) async {
    RandomAccessFile raf;
    try {
      raf = File(path).openSync(mode: FileMode.read);
    } catch (_) {
      return null;
    }
    final z = ApkZip._(path, raf);
    if (!z._readCentralDirectory()) {
      z.close();
      return null;
    }
    return z;
  }

  void close() {
    try {
      _raf.closeSync();
    } catch (_) {}
  }

  int _u32(int off) => _raf.lengthSync() > 0 ? _readU32(off) : 0;

  int _readU32(int off) {
    _raf.setPositionSync(off);
    final b = _raf.readSync(4);
    return b[0] | (b[1] << 8) | (b[2] << 16) | (b[3] << 24);
  }

  int _readU16(int off) {
    _raf.setPositionSync(off);
    final b = _raf.readSync(2);
    return b[0] | (b[1] << 8);
  }

  bool _readCentralDirectory() {
    try {
      final len = _raf.lengthSync();
      if (len < 100) return false;
      // cari EOCD dari belakang (max 64KB + zip64)
      final tailSize = len > 66000 ? 66000 : len;
      _raf.setPositionSync(len - tailSize);
      final tail = _raf.readSync(tailSize);
      int eocd = -1;
      for (int i = tail.length - 22; i >= 0; i--) {
        if (tail[i] == 0x50 && tail[i + 1] == 0x4B && tail[i + 2] == 0x05 && tail[i + 3] == 0x06) {
          eocd = i;
          break;
        }
      }
      if (eocd < 0) return false;
      final b = ByteData.sublistView(tail, eocd);
      final total = b.getUint16(10, Endian.little) | (b.getUint16(8, Endian.little) << 16);
      final cdSize = b.getUint32(12, Endian.little);
      var cdOffset = b.getUint32(16, Endian.little);
      // zip64: offset/count bisa 0xFFFFFFFF — baca dari zip64 EOCD kalau ada
      if (cdOffset == 0xFFFFFFFF || total == 0xFFFF) {
        // cari zip64 locator (PK\x06\x07) sebelum EOCD
        for (int i = eocd - 20; i >= 0; i--) {
          if (tail[i] == 0x50 && tail[i + 1] == 0x4B && tail[i + 2] == 0x06 && tail[i + 3] == 0x07) {
            final z64off = ByteData.sublistView(tail, i).getUint64(8, Endian.little);
            _raf.setPositionSync(z64off);
            final z64 = _raf.readSync(56);
            final z = ByteData.sublistView(z64);
            if (z.getUint32(0, Endian.little) == 0x06064B50) {
              final realTotal = z.getUint64(32, Endian.little);
              final realCdSize = z.getUint64(40, Endian.little);
              final realCdOffset = z.getUint64(48, Endian.little);
              return _parseCd(realCdOffset, realCdSize, realTotal);
            }
            break;
          }
        }
      }
      return _parseCd(cdOffset, cdSize, total & 0xFFFF);
    } catch (_) {
      return false;
    }
  }

  bool _parseCd(int cdOffset, int cdSize, int total) {
    try {
      if (cdOffset < 0 || cdSize <= 0 || total > 200000) return false;
      _raf.setPositionSync(cdOffset);
      Uint8List cd;
      if (cdSize > 64 * 1024 * 1024) {
        // central dir besar: baca stream per-chunk, hanya ambil header 46 byte
        int count = 0;
        int pos = cdOffset;
        while (count < total) {
          final sig = _readU32(pos);
          if (sig != 0x02014B50) break;
          final nameLen = _readU16(pos + 28);
          final extraLen = _readU16(pos + 30);
          final commentLen = _readU16(pos + 32);
          final method = _readU16(pos + 10);
          final csize = _readU32(pos + 20);
          final usize = _readU32(pos + 24);
          final lho = _readU32(pos + 42);
          _raf.setPositionSync(pos + 46);
          final nameB = _raf.readSync(nameLen);
          final name = String.fromCharCodes(nameB);
          entries.add(ZipEntryInfo(name, method, csize, usize, lho));
          _byName[name] = entries.last;
          pos = pos + 46 + nameLen + extraLen + commentLen;
          count++;
        }
        return entries.isNotEmpty;
      }
      _raf.setPositionSync(cdOffset);
      cd = _raf.readSync(cdSize);
      final bd = ByteData.sublistView(cd);
      int p = 0;
      int count = 0;
      while (p + 46 <= cd.length && count < total) {
        if (bd.getUint32(p, Endian.little) != 0x02014B50) break;
        final method = bd.getUint16(p + 10, Endian.little);
        final csize = bd.getUint32(p + 20, Endian.little);
        final usize = bd.getUint32(p + 24, Endian.little);
        final nameLen = bd.getUint16(p + 28, Endian.little);
        final extraLen = bd.getUint16(p + 30, Endian.little);
        final commentLen = bd.getUint16(p + 32, Endian.little);
        final lho = bd.getUint32(p + 42, Endian.little);
        if (p + 46 + nameLen > cd.length) break;
        final name = String.fromCharCodes(cd.sublist(p + 46, p + 46 + nameLen));
        entries.add(ZipEntryInfo(name, method, csize, usize, lho));
        _byName[name] = entries.last;
        p += 46 + nameLen + extraLen + commentLen;
        count++;
      }
      return entries.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  ZipEntryInfo? find(String name) => _byName[name];

  List<String> namesWhere(bool Function(String) test) => entries.where((e) => test(e.name)).map((e) => e.name).toList();

  /// Ekstrak entri ke file (streaming, chunked deflate).
  Future<bool> extract(ZipEntryInfo e, String destPath, {void Function(int, int)? onProgress}) async {
    try {
      final sig = _readU32(e.localOffset);
      if (sig != 0x04034B50) return false;
      final nameLen = _readU16(e.localOffset + 26);
      final extraLen = _readU16(e.localOffset + 28);
      final dataOff = e.localOffset + 30 + nameLen + extraLen;
      final csize = e.compressedSize;
      if (csize == 0xFFFFFFFF || e.uncompressedSize == 0xFFFFFFFF) return false; // zip64 entri — jarang di APK
      final out = File(destPath).openSync(mode: FileMode.write);
      try {
        if (e.method == 0) {
          // stored
          const chunk = 1 << 22;
          int done = 0;
          while (done < csize) {
            final n = (csize - done < chunk) ? csize - done : chunk;
            _raf.setPositionSync(dataOff + done);
            final b = _raf.readSync(n);
            out.writeFromSync(b);
            done += n;
            if (onProgress != null) onProgress(done, csize);
          }
        } else if (e.method == 8) {
          // deflate — chunked decode
          const chunk = 1 << 22;
          int done = 0;
          final decoder = ZLibDecoder(raw: true);
          final sink = decoder.startChunkedConversion(_FileSink(out, e.uncompressedSize, onProgress));
          while (done < csize) {
            final n = (csize - done < chunk) ? csize - done : chunk;
            _raf.setPositionSync(dataOff + done);
            final b = _raf.readSync(n);
            sink.add(b);
            done += n;
            if (onProgress != null) onProgress(done, csize);
          }
          sink.close();
        } else {
          return false;
        }
      } finally {
        out.flushSync();
        out.closeSync();
      }
      final f = File(destPath);
      return f.existsSync() && f.lengthSync() > 0;
    } catch (_) {
      return false;
    }
  }
}

class _FileSink implements Sink<List<int>> {
  final RandomAccessFile _out;
  final int _total;
  int _written = 0;
  final void Function(int, int)? _onProgress;
  _FileSink(this._out, this._total, this._onProgress);
  @override
  void add(List<int> data) {
    _out.writeFromSync(data);
    _written += data.length;
    if (_onProgress != null) _onProgress(_written, _total);
  }

  @override
  void close() {}
}
