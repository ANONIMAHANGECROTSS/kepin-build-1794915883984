// KepinDumper: background video (muted, loop, blur) buat main page.
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'palette.dart';

class VideoBackground extends StatefulWidget {
  final String url;
  final double blur;
  const VideoBackground({super.key, required this.url, this.blur = 14});
  @override
  State<VideoBackground> createState() => _VideoBackgroundState();
}

class _VideoBackgroundState extends State<VideoBackground> {
  VideoPlayerController? _controller;
  bool _failed = false;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    final c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
    try {
      await c.initialize();
      await c.setVolume(0);
      c.setLooping(true);
      await c.play();
      if (!mounted) {
        c.dispose();
        return;
      }
      setState(() => _controller = c);
    } catch (_) {
      if (!mounted) return;
      setState(() => _failed = true);
      try {
        c.dispose();
      } catch (_) {}
    }
  }

  @override
  void dispose() {
    try {
      _controller?.dispose();
    } catch (_) {}
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final c = _controller;
    if (c != null && c.value.isInitialized) {
      final size = c.value.size;
      // cover-fit
      final scale = (w / size.width > h / size.height) ? w / size.width : h / size.height;
      return Positioned.fill(
        child: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: widget.blur, sigmaY: widget.blur),
            child: Container(
              color: kBg.withOpacity(0.55),
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: size.width * scale,
                  height: size.height * scale,
                  child: VideoPlayer(c),
                ),
              ),
            ),
          ),
        ),
      );
    }
    // fallback: gradient gelap + tekstur grid halus
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: const Alignment(-0.4, -0.6),
            radius: 1.2,
            colors: [kSurface2, kBgDeep, kBgDeep],
          ),
        ),
      ),
    );
  }
}

/// Overlay gelap di atas background biar konten kontras.
class Scrim extends StatelessWidget {
  final double topOpacity;
  final double bottomOpacity;
  const Scrim({super.key, this.topOpacity = 0.35, this.bottomOpacity = 0.86});
  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: DecoratedBox(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [kBg.withOpacity(topOpacity), kBg.withOpacity(0.72), kBg.withOpacity(bottomOpacity)],
          ),
        ),
      ),
    );
  }
}
