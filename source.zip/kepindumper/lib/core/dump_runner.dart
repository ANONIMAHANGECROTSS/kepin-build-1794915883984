// KepinDumper: dump runner di isolate terpisah biar UI tetap smooth.

import 'dart:async';
import 'dart:isolate';
import '../engine/dumper.dart';

class DumpProgressMsg {
  final String phase;
  final int pct;
  final String detail;
  const DumpProgressMsg(this.phase, this.pct, this.detail);
}

class DumpDoneMsg {
  final Map<String, dynamic> payload;
  const DumpDoneMsg(this.payload);
}

class DumpRunner {
  /// Jalankan dump di isolate; [onProgress] dipanggil di isolate utama.
  /// Return payload: {ok, error, outDir, files, stats}.
  static Future<Map<String, dynamic>> start({
    required String il2cppPath,
    required String metadataPath,
    required String outDir,
    void Function(DumpProgressMsg)? onProgress,
  }) {
    final completer = Completer<Map<String, dynamic>>();
    final port = ReceivePort();
    StreamSubscription? sub;
    Isolate.spawn(_entry, [port.sendPort, il2cppPath, metadataPath, outDir]).catchError((Object e) {
      if (!completer.isCompleted) {
        completer.complete({'ok': false, 'error': 'Gak bisa spawn isolate: $e'});
      }
    });
    sub = port.listen((msg) {
      if (msg is DumpProgressMsg) {
        onProgress?.call(msg);
        return;
      }
      if (msg is DumpDoneMsg) {
        sub?.cancel();
        port.close();
        if (!completer.isCompleted) {
          completer.complete(msg.payload);
        }
      }
    });
    return completer.future;
  }

  static void _entry(List<dynamic> args) {
    final send = args[0] as SendPort;
    try {
      final r = runDump(
        il2cppPath: args[1] as String,
        metadataPath: args[2] as String,
        outDir: args[3] as String,
        onProgress: (phase, pct, detail) {
          send.send(DumpProgressMsg(phase, pct, detail));
        },
      );
      send.send(DumpDoneMsg({
        'ok': r.ok,
        'error': r.error,
        'outDir': r.outDir,
        'files': r.files,
        'stats': r.stats,
      }));
    } catch (e) {
      send.send(DumpDoneMsg({'ok': false, 'error': e.toString(), 'outDir': '', 'files': <String>[], 'stats': const <String, dynamic>{}}));
    }
  }
}
