// KepinDumper: auth page — biometrik dummy (5 detik) → splash.

import 'dart:async';
import 'package:flutter/material.dart';
import '../core/palette.dart';
import 'splash_page.dart';

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> with SingleTickerProviderStateMixin {
  double _progress = 0;
  bool _running = false;
  Timer? _timer;
  late final AnimationController _pulse;

  static const _stages = [
    (0.0, 0.36, 'Memverifikasi biometrik'),
    (0.36, 0.72, 'Memuat engine dump'),
    (0.72, 1.0, 'Menyiapkan runtime'),
  ];

  String get _stage {
    for (final s in _stages) {
      if (_progress < s.$2) return s.$3;
    }
    return 'Selesai';
  }

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 1600))..repeat(reverse: true);
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulse.dispose();
    super.dispose();
  }

  void _start() {
    if (_running) return;
    setState(() {
      _running = true;
      _progress = 0;
    });
    const total = Duration(milliseconds: 5000);
    const tick = Duration(milliseconds: 50);
    var elapsed = 0;
    _timer = Timer.periodic(tick, (t) {
      elapsed += tick.inMilliseconds;
      final p = elapsed / total.inMilliseconds;
      if (p >= 1.0) {
        t.cancel();
        setState(() => _progress = 1);
        Timer(const Duration(milliseconds: 500), _go);
      } else {
        setState(() => _progress = p);
      }
    });
  }

  void _go() {
    if (!mounted) return;
    Navigator.of(context).pushReplacement(kFadeRoute(const SplashPage()));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: kBgDeep,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 28),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const Spacer(flex: 3),
              // wordmark
              Column(
                children: [
                  Text('KEPIN', style: kDisplay(size: 40, w: FontWeight.w700, c: kText, ls: 3)),
                  Text('DUMPER', style: kDisplay(size: 40, w: FontWeight.w700, c: kLime, ls: 3)),
                  const SizedBox(height: 10),
                  Text('IL2CPP GUI DUMPER ENGINE', style: kMono(size: 10, c: kFaint, ls: 2.4)),
                ],
              ),
              const Spacer(flex: 2),
              // sidik jari
              GestureDetector(
                onTap: _start,
                child: AnimatedBuilder(
                  animation: _pulse,
                  builder: (context, _) {
                    final glow = 0.25 + 0.35 * _pulse.value;
                    final scale = 1.0 + 0.04 * _pulse.value;
                    return Transform.scale(
                      scale: _running ? 1.04 : scale,
                      child: Container(
                        width: 128,
                        height: 128,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: kSurface,
                          border: Border.all(color: _running ? kMint : kLime.withOpacity(0.6), width: 1.4),
                          boxShadow: [
                            BoxShadow(
                              color: (_running ? kMint : kLime).withOpacity(glow),
                              blurRadius: 34 + 18 * _pulse.value,
                              spreadRadius: 1,
                            ),
                          ],
                        ),
                        child: Icon(Icons.fingerprint, size: 62, color: _running ? kMint : kLime),
                      ),
                    );
                  },
                ),
              ),
              const SizedBox(height: 18),
              Text(
                _running ? _stage.toUpperCase() : 'TEKAN SIDIK JARI UNTUK MULAI',
                style: kMono(size: 11, w: FontWeight.w700, c: _running ? kMint : kDim, ls: 1.6),
              ),
              const Spacer(flex: 2),
              // progress
              AnimatedOpacity(
                opacity: _running ? 1 : 0,
                duration: kAnim,
                child: SizedBox(
                  width: double.infinity,
                  child: KCard(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text('AUTENTIKASI', style: kMono(size: 10, c: kFaint, ls: 1.4)),
                            Text('${(_progress * 100).toStringAsFixed(0)}%',
                                style: kMono(size: 13, w: FontWeight.w700, c: kLime)),
                          ],
                        ),
                        const SizedBox(height: 12),
                        KBar(value: _progress),
                      ],
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 22),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const KChip(text: 'v3.0 ENGINE', color: kLimeDim),
                  const SizedBox(width: 8),
                  const KChip(text: 'DACM BUILD', color: kFaint),
                ],
              ),
              const SizedBox(height: 26),
            ],
          ),
        ),
      ),
    );
  }
}
