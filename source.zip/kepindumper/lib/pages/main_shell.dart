// KepinDumper: main shell — background video blur + navbar + gate izin.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter_overlay_window/flutter_overlay_window.dart';
import '../core/palette.dart';
import '../core/video_bg.dart';
import 'upload_page.dart';
import 'float_page.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> with WidgetsBindingObserver {
  final PageController _page = PageController();
  int _tab = 0;
  bool _allFiles = false;
  bool _overlay = false;
  bool _gateVisible = true;
  bool _dismissed = false;

  static const _bgUrl = 'https://files.catbox.moe/3yw4qv.mp4';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _checkPerms();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _page.dispose();
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      _checkPerms();
    }
  }

  Future<void> _checkPerms() async {
    bool allFiles = false;
    bool overlay = false;
    try {
      allFiles = await Permission.manageExternalStorage.isGranted;
    } catch (_) {}
    try {
      overlay = await FlutterOverlayWindow.isPermissionGranted();
    } catch (_) {}
    if (!mounted) return;
    setState(() {
      _allFiles = allFiles;
      _overlay = overlay;
      if (allFiles && overlay) _gateVisible = false;
      if (!allFiles || !overlay) _dismissed = false;
    });
  }

  Future<void> _grantAll() async {
    try {
      if (!_allFiles) {
        final st = await Permission.manageExternalStorage.request();
        if (st.isGranted) _allFiles = true;
      }
    } catch (_) {}
    try {
      if (!_overlay) {
        _overlay = await FlutterOverlayWindow.requestPermission();
      }
    } catch (_) {}
    _checkPerms();
  }

  @override
  Widget build(BuildContext context) {
    final grantedAll = _allFiles && _overlay;
    final showGate = !grantedAll && !_dismissed;
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: SystemUiOverlayStyle.light,
      child: Scaffold(
        backgroundColor: kBg,
        body: Stack(
          children: [
            const VideoBackground(url: _bgUrl, blur: 16),
            const Scrim(),
            SafeArea(
              bottom: false,
              child: Column(
                children: [
                  // header
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 14, 20, 0),
                    child: Row(
                      children: [
                        Container(
                          width: 34,
                          height: 34,
                          decoration: BoxDecoration(
                            color: kLime,
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Center(
                            child: Text('K', style: kDisplay(size: 16, w: FontWeight.w700, c: kBgDeep)),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Text('KEPIN DUMPER', style: kDisplay(size: 17, w: FontWeight.w700, c: kText, ls: 1.6)),
                        const Spacer(),
                        KChip(text: grantedAll ? 'SIAP' : 'IZIN?', color: grantedAll ? kMint : kAmber),
                      ],
                    ),
                  ),
                  // pages
                  Expanded(
                    child: PageView(
                      controller: _page,
                      onPageChanged: (i) => setState(() => _tab = i),
                      children: const [UploadPage(), FloatPage()],
                    ),
                  ),
                ],
              ),
            ),
            // navbar
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: _NavBar(current: _tab, onChange: (i) {
                _page.animateToPage(i, duration: kAnim, curve: Curves.easeOutCubic);
              }),
            ),
            // gate izin
            if (showGate) _PermGate(onGrant: _grantAll, onDismiss: () => setState(() => _dismissed = true)),
          ],
        ),
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  final int current;
  final ValueChanged<int> onChange;
  const _NavBar({required this.current, required this.onChange});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: false,
      child: Container(
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 14),
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          color: kBgDeep.withOpacity(0.72),
          borderRadius: BorderRadius.circular(26),
          border: Border.all(color: kStroke),
        ),
        child: Row(
          children: [
            _navItem(0, 'UPLOAD', Icons.cloud_upload_outlined),
            _navItem(1, 'FLOAT', Icons.picture_in_picture_alt_rounded),
          ],
        ),
      ),
    );
  }

  Widget _navItem(int i, String label, IconData icon) {
    final sel = current == i;
    return Expanded(
      child: KTap(
        onTap: () => onChange(i),
        child: AnimatedContainer(
          duration: kAnim,
          curve: Curves.easeOutCubic,
          padding: const EdgeInsets.symmetric(vertical: 11),
          decoration: BoxDecoration(
            color: sel ? kLime.withOpacity(0.14) : Colors.transparent,
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: sel ? kLime.withOpacity(0.5) : Colors.transparent, width: 1),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 18, color: sel ? kLime : kFaint),
              const SizedBox(width: 8),
              Text(
                label,
                style: kMono(size: 11, w: FontWeight.w700, c: sel ? kLime : kFaint, ls: 1.8),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _PermGate extends StatefulWidget {
  final VoidCallback onGrant;
  final VoidCallback onDismiss;
  const _PermGate({required this.onGrant, required this.onDismiss});
  @override
  State<_PermGate> createState() => _PermGateState();
}

class _PermGateState extends State<_PermGate> {
  bool _busy = false;

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: Container(
        color: kBgDeep.withOpacity(0.62),
        child: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0.0, end: 1.0),
                duration: kAnim,
                curve: Curves.easeOutCubic,
                builder: (context, t, child) => Transform.scale(
                  scale: 0.94 + 0.06 * t,
                  child: Opacity(opacity: t, child: child),
                ),
                child: KCard(
                  padding: const EdgeInsets.all(22),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          const Icon(Icons.security_rounded, color: kLime, size: 20),
                          const SizedBox(width: 10),
                          Text('IZIN DIBUTUHKAN', style: kDisplay(size: 15, w: FontWeight.w700, c: kText, ls: 1.2)),
                          const Spacer(),
                          KTap(
                            onTap: widget.onDismiss,
                            child: const Icon(Icons.close, color: kFaint, size: 18),
                          ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text('KepinDumper butuh izin ini biar engine-nya jalan penuh.',
                          style: kBody(size: 12, c: kDim)),
                      const SizedBox(height: 16),
                      _row(Icons.folder_outlined, 'Akses Semua File', 'simpan hasil dump ke /storage/emulated/0/KepinDumper'),
                      const SizedBox(height: 10),
                      _row(Icons.layers_outlined, 'Tampil di Atas App', 'window melayang FLOAT buat dump game'),
                      const SizedBox(height: 18),
                      _busy
                          ? const Center(child: SizedBox(width: 140, child: KBar(value: 0.5)))
                          : KPrimaryButton(
                              label: 'IZINKAN SEMUA',
                              icon: Icons.key_rounded,
                              onTap: () async {
                                setState(() => _busy = true);
                                await widget.onGrant();
                                if (mounted) setState(() => _busy = false);
                              },
                            ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _row(IconData icon, String title, String sub) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Container(
          width: 38,
          height: 38,
          decoration: BoxDecoration(color: kSurfaceHi, borderRadius: BorderRadius.circular(12)),
          child: Icon(icon, color: kLime, size: 18),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: kBody(size: 13, w: FontWeight.w700, c: kText)),
              const SizedBox(height: 2),
              Text(sub, style: kMono(size: 10, c: kFaint)),
            ],
          ),
        ),
      ],
    );
  }
}
